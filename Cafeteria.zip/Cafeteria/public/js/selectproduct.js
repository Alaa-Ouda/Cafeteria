$(function(){
	$('#confirm').before('<p>----------------</p>');
	$('#confirm').before($('#total_price'));
	$('#confirm').before($('#currency'));
	$('#confirm').before('<br/>');

	$('#prod_cat').after($('#addcategory'));

	$('#users').on('change',function(){
		user_id = $('#users').attr('value');
		user_name = $('#users').text();
		$('#user_id').attr('value',user_id);
		$.ajax({
	        url:"/order/chooseuser",
	        cache:false,
	        type: "POST", // HTTP method POST or GET
	        dataType:"html", // Data type, HTML, json etc.
	        data:{
	        	user_id:user_id,
	        	user_name:user_name,
	        	}, //Form variables
	      	success:function(r){
	      		//console.log(r);
	      	},
	      	error:function(){
	        	console.log("Error");
	      	}
		});
	});

	//alert(true);
	// img = document.getElementById('product_image');
	// img.addEventListener('click', function(){
	// 	alert('zzzzzzzzzz');
	// });
//console.log('hiii');
//console.log($('#choosed_product_name').html());
	flag = false;
	var prod_id;
	var prod_name;
	var prod_price;
	var prod_quantity;
	var prices=0;
	//var product = [];
	//alert($.session.get("products"));
	// if($.session.get("products")){
	// 	console.log($.session.get("products"));
	// }
	$('.product_image').on('click',function(){
		//alert(true);
		//e.preventDefault();
		//alert($(this).prop('id'));
		//alert($('.'+$(this).prop('id')).children('#product_name').html());
		prod_id = $(this).attr('id');
		prod_name = $(this).attr('name');
		prod_price = $(this).attr('price');
		prod_quantity=1;
			//console.log($('#choosed_products').find('tr[id='+prod_id+']'));
		//if($('tr[id='+prod_id+']').html()==''){alert(false);
		if($('#choosed_products').find('tr[id='+prod_id+']').length != 0){
			//console.log($('#choosed_products').find('tr[id='+prod_id+']').length);
			quantity = parseInt($('#quantity_'+prod_id).attr('value'));
			quantity++;
			prod_quantity = quantity;
			$('#quantity_'+prod_id).attr('value',quantity);
//alert($('#price_'+prod_id).html());
			price = parseInt($('#price_'+prod_id).html());
			price=prod_price*quantity;
			prod_price = price;
			$('#price_'+prod_id).html(price);

		}else{//alert(true);

			choosed_prod = '<tr id="'+prod_id+
			'"><td><label id="choosed_product_name">'+prod_name+
			'</label></td><td><input type="number" name="quantity" id="quantity_'+prod_id+'" value="1" /></td><td>'+
    '<input type="button" class="plus" id="'+prod_id+'" value="+"><input type="button" class="minus" id="'+prod_id+'" value="-"></td><td><label class="price" id="price_'+prod_id+'">'
			+prod_price+'</label></td><td> L.E. <input type="button" class="close" id="'+prod_id+'" value="x"></td></tr>';
			//$('#choosed_products').css('display','block');
			$('#choosed_products').append(choosed_prod);
			
			// product['id']=prod_id;
			// product['name']=prod_name;
			// product['quantity']=1;
			// product['price']=prod_price;
			// $.session.set("products", product);
		}
		
			//prices+=parseInt(prod_price);
		prices=0;
		$('#choosed_products tr').find('.price').each(function(){
			//prices =0;
			prices += parseInt($(this).html());
			$('#total_price').html(prices);
		});

		sendProductData();		
		 //console.log(prices);
		// $.ajax({
	 //        url:"order/chooseproduct",
	 //        cache:false,
	 //        type: "POST", // HTTP method POST or GET
	 //        dataType:"html", // Data type, HTML, json etc.
	 //        data:{
	 //        	prod_id:prod_id,
	 //        	prod_name:prod_name,
	 //        	prod_price:prod_price,
	 //        	prod_quantity:prod_quantity,
	 //        	}, //Form variables
	 //      success:function(r){
	 //      	console.log(r);
	 //      },
	 //      error:function(){
	 //        console.log("Error");
	 //      }

	 //    });

		// $.ajax({
	 //        url:"order/chooseproduct",
	 //        cache:false,
	 //        type: "POST", // HTTP method POST or GET
	 //        dataType:"html", // Data type, HTML, json etc.
	 //        data:"prod_id="+prod_id, //Form variables
	 //      success:function(r){
	 //      	console.log(r);
	 //        r = r.split('@');
	 //        if(r.length>0){
	 //        	//alert(true);
	 //        	$(r[0]).children($('product_quantity')).html(r[1]);
	 //        }
	 //        else
	 //      		$('#notes_label').before(r);
	 //        // $('#id').val(r[0]);
	 //        // $('#username').val(r[1]);
	 //        // $('#email').val(r[2]);
	 //        // $('#update_'+r[0]).text('Save');
	 //        // $('#submit').val('Save');
	 //        // $('#cancel').show();
	 //      },
	 //      error:function(){
	 //        console.log("Error");
	 //      }

	 //    });
		//console.log($(prod_id).prop('class'));
		// data = $(prod_id).prop('class');
		// prod_data = data.split('@');
		// console.log(prod_data[0]);
		// prod_data = $('.cols2').children('#choosed_'+prod_id);
		// if(prod_data==null){
		// 	prod_name = $('.'+prod_id).children('#product_name').html();
		// 	prod_price = $('.'+prod_id).children('#product_price').html();
		// 	prod = '<div id="choosed_'+prod_id+'"><label id="choosed_product_name">'+prod_name+'</label><input type="number" name="quantity" id="product_quantity" /><label>+</label><label>-</label><label id="product_price">'+prod_price+' L.E.</label><label>X</label></div><br/>'
		// 	$('#notes_label').before(prod);
		// }else{
		// 	console.log(prod_data);
		// }
		//$('#choosed_product_name').html($('.product_name').html());
	});
	$('body').delegate(".plus", 'click', function () { 
		prod_id = $(this).attr('id');
		prod_name = $(this).attr('name');

		price = parseInt($('#price_'+prod_id).html());
		prod_quantity = $('#quantity_'+prod_id).attr('value');
		//alert(prod_quantity);
		price = price/prod_quantity;

		prod_quantity++;
		$('#quantity_'+prod_id).attr('value',prod_quantity);

		prod_price=price*prod_quantity;
		//prod_price = price;
		$('#price_'+prod_id).html(prod_price);

		prices = parseInt($('#total_price').html());
		prices+=price;
		// alert(prices);
		// $('#choosed_products tr').find('.price').each(function(){
		// 	//prices =0;
		// 	prices += parseInt($(this).html());
			$('#total_price').html(prices);
		// });
	sendProductData();
	});

	$('body').delegate(".minus", 'click', function () { 
		prod_id = $(this).attr('id');
		prod_name = $(this).attr('name');

		prod_price = parseInt($('#price_'+prod_id).html());
		prod_quantity = $('#quantity_'+prod_id).attr('value');

		price = prod_price/prod_quantity;
		
		if(prod_quantity > 1){
			prod_quantity--;
			$('#quantity_'+prod_id).attr('value',prod_quantity);

			prod_price-=price;
			//prod_price = price;
			$('#price_'+prod_id).html(prod_price);
		}else{
			$('tr[id='+prod_id+']').remove();
		}

		prices = $('#total_price').html();
		prices-=price;
		// $('#choosed_products tr').find('.price').each(function(){
		// 	//prices =0;
		// 	prices += parseInt($(this).html());
		$('#total_price').html(prices);
		// });	
	sendProductData();
	});


	$('body').delegate(".close", 'click', function () { 
		prod_id = $(this).attr('id');
		prod_price = parseInt($('#price_'+prod_id).html());

		$('tr[id='+prod_id+']').remove();

		prices = $('#total_price').html();
		prices-=prod_price;
		// prices=0;
		// $('#choosed_products tr').find('.price').each(function(){
		// 	//prices =0;
		// 	prices += parseInt($(this).html());
			$('#total_price').html(prices);
		//});
	deleteProductData();
	});

	function sendProductData(){
		$.ajax({
	        url:"/order/chooseproduct",
	        cache:false,
	        type: "POST", // HTTP method POST or GET
	        dataType:"html", // Data type, HTML, json etc.
	        data:{
	        	prod_id:prod_id,
	        	prod_name:prod_name,
	        	prod_price:prod_price,
	        	prod_quantity:prod_quantity,
	        	}, //Form variables
	      	success:function(r){
	      		//console.log(r);
	      	},
	      	error:function(){
	        	console.log("Error");
	      	}
		});
	}

	function deleteProductData(){
		$.ajax({
	        url:"/order/chooseproduct",
	        cache:false,
	        type: "POST", // HTTP method POST or GET
	        dataType:"html", // Data type, HTML, json etc.
	        data:{
	        	prod_id:prod_id,
	        	status:'close',
	        	}, //Form variables
	      	success:function(r){
	      		//console.log(r);
	      	},
	      	error:function(){
	        	console.log("Error");
	      	}
		});
	}
	// $('.plus').on('click',function(){//alert(true);
	// 	prod_id = $(this).attr('id');
	// 	price = parseInt($('#price_'+prod_id).html());
	// 	quantity = $('#quantity_'+prod_id).attr('value');

	// 	prod_price = price/quantity;

	// 	quantity++;
	// 	$('#quantity_'+prod_id).attr('value',quantity);

	// 	price=prod_price*quantity;
	// 	//prod_price = price;
	// 	$('#price_'+prod_id).html(price);
	// });

	// $('.minus').on('click',function(){
	// 	prod_id = $(this).attr('id');
	// 	price = parseInt($('#price_'+prod_id).html());
	// 	quantity = $('#quantity_'+prod_id).attr('value');

	// 	prod_price = price/quantity;
		
	// 	if(quantity > 1){
	// 		quantity--;
	// 		$('#quantity_'+prod_id).attr('value',quantity);

	// 		price-=prod_price;
	// 		//prod_price = price;
	// 		$('#price_'+prod_id).html(price);
	// 	}else{
	// 		$('tr[id='+prod_id+']').remove();
	// 	}
	// });

	// $('.close').on('click',function(){
	// 	prod_id = $(this).attr('id');
	// 	$('tr[id='+prod_id+']').remove();
	// });
	
});