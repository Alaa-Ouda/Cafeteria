<?php
 $category = new Application_Model_Category();
 $res = $category->listCategories();
 print_r($res);
// for($i=0;$i<count($res);$i++){
//       echo "<tr>";
//        
//            echo '<td>'.$posts[$i]['ptitle'].'</td>';
//            
//            
//        
//        $pid = $posts[$i]['pid'];
//        echo '<td>';
//        echo '<a href="'.$base.'/post/edit/id/'.$pid.'">Edit</a>';
//        echo '<a href="'.$base.'/post/delete/id/'.$pid.'">Delete</a>';
//        echo '<a href="'.$base.'/post/view/id/'.$pid.'">View</a>';
//        echo '</td>';
//        echo "</tr>";
//        
//    }
// 


