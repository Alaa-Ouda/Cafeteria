<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap {

	protected function _initDoctype() {
		Zend_View_Helper_PaginationControl::setDefaultViewPartial('pages.phtml');
		$this->bootstrap('view');
		$view = $this->getResource('view');
		$view->doctype('XHTML1_STRICT');

		// $url       = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
		// $url_array = explode('/', $url);
		//print_r($url_array);
		//die();
		//if (count($url_array) == 2) {
		//echo $view->baseUrl('style.css');
		//die();
		$view->headLink()->headLink(array('rel' => 'shortcut icon',
				'href'                                => 'css/images/favicon.ico'),
			'APPEND');
		$view->headLink()->appendStylesheet($view->baseUrl().'/css/style.css');
		$view->headLink()->appendStylesheet($view->baseUrl().'/css/flexslider.css');
		$view->headLink()->appendStylesheet($view->baseUrl().'/js/jquery-ui-1.11.4.custom/jquery-ui.css');

		$view->headScript()->appendFile($view->baseUrl().'/js/jquery-1.11.2.js');
		// $view->headScript()->appendFile($view->baseUrl().'/js/jquery-ui-1.11.4.custom/external/jquery/jquery.js');
		// $view->headScript()->appendFile($view->baseUrl().'/js/jquery-ui-1.11.4.custom/jquery-ui.js');

		$view->headScript()->appendFile($view->baseUrl().'/js/selectproduct.js');
		$view->headScript()->appendFile($view->baseUrl().'/js/checks.js');
		$view->headScript()->appendFile($view->baseUrl().'/js/getorder.js');

		$view->headScript()->appendFile($view->baseUrl().'/js/jquery-1.8.0.min.js');
		$view->headScript()->appendFile($view->baseUrl().'/js/jquery.flexslider-min.js');
		$view->headScript()->appendFile($view->baseUrl().'/js/functions.js');

		$view->headScript()->appendFile($view->baseUrl().'/js/jquery.session.js');

		// print_r($url_array[0]);
		// die();

		// } else {

		// 	$view->headLink()->headLink(array('rel' => 'shortcut icon',
		// 			'href'                                => '../../public/css/images/favicon.ico'),
		// 		'APPEND');
		// 	$view->headLink()->appendStylesheet('../../public/css/style.css');
		// 	$view->headLink()->appendStylesheet('../../public/css/flexslider.css');
		// 	$view->headScript()->appendFile('../../public/js/jquery-1.8.0.min.js');
		// 	$view->headScript()->appendFile('../../public/js/jquery.flexslider-min.js');
		// 	$view->headScript()->appendFile('../../public/js/functions.js');
		// }
	}
}
