<?php

class Application_Model_Rooms extends Zend_Db_Table_Abstract
{
    protected $_name="rooms";
    
    function getRooms()
    {
        return $this->fetchAll()->toArray();
    }
}

