<?php

class Application_Form_Order extends Zend_Form {

	public function init() {
		/// step 1 create form
		//$order_id = new Zend_Form_Element_Hidden("order_id");

		$this->setMethod('post');
		//$this->setAction('/order/add/');
		$this->setAttrib('id', 'addorder');
		$user_id = new Zend_Form_Element_Hidden("user_id");
		$user_id->setAttrib('id', 'user_id');
		// $order_status=new Zend_Form_Element_Text("order_status");
		// $order_status->setLabel("order_status");
		//  $order_status->setRequired();

		$order_notes = new Zend_Form_Element_Textarea("order_notes");
		$order_notes->setAttrib('rows', '4');
		$order_notes->setAttrib('cols', '30');
		$order_notes->setLabel("Notes");
		//$order_notes->setRequired();

		// $user_id->setLabel("user_id");
		// $user_id->setRequired();
		// $total_price = '<br/>---------------------------<br/>'.
		//'<label id="total_price"></label> L.E.<br/>';
		$add = new Zend_Form_Element_Submit("Confirm");
		$add->setAttrib('id', 'confirm');
		//$add->setLabel("add");

		$rooms = new Zend_Form_Element_Select("room_no");
		$rooms->setLabel("Room");

		/*********************************/

		//         $qunantity2= new Zend_Form_Element_Text("pro_amount[]");
		//         $qunantity2->setLabel("enter amount2");
		//         $qunantity2->setRequired();

		// $qunantity1 = new Zend_Form_Element_Text("pro_amount");
		// $qunantity1->setLabel("Product Amount");

		//         $pro_id1=new Zend_Form_Element_Hidden("pro_id");

		$this->addElements(array($order_notes, $rooms, $user_id, $add));
		//2015-04-09 00:00:00
	}

}
